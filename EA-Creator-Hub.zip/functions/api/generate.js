const allowedTools = new Set(["copy","roteiro","anuncio","hashtags","ganchos","landing","ideias","identidade","test"]);

export async function onRequestPost({ request, env }) {
  const headers = {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff"
  };

  try {
    if (!env.GEMINI_API_KEY) {
      return Response.json({
        error: "A chave do Gemini ainda não foi configurada. Na Cloudflare Pages, adicione GEMINI_API_KEY em Settings → Variables and Secrets e publique novamente."
      }, { status: 503, headers });
    }

    const body = await request.json().catch(() => null);
    if (!body || typeof body.prompt !== "string") {
      return Response.json({ error: "Pedido inválido. Envie um texto para gerar conteúdo." }, { status: 400, headers });
    }

    const prompt = body.prompt.trim();
    const tool = typeof body.tool === "string" ? body.tool : "copy";
    if (!prompt || prompt.length > 12000) {
      return Response.json({ error: "O texto precisa ter entre 1 e 12.000 caracteres." }, { status: 400, headers });
    }
    if (!allowedTools.has(tool)) {
      return Response.json({ error: "Ferramenta não reconhecida." }, { status: 400, headers });
    }

    const model = (env.GEMINI_MODEL || "gemini-3.8-flash").trim();
    const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;

    const upstream = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": env.GEMINI_API_KEY
      },
      body: JSON.stringify({
        systemInstruction: {
          parts: [{
            text: "Você é o assistente criativo do EA Creator Hub. Responda sempre em português brasileiro, com clareza, utilidade e organização. Não invente fatos, resultados, avaliações ou características que o usuário não forneceu. Se faltarem informações importantes, indique suposições ou use campos [EDITAR]. Para pedidos de código, produza código legível e explique onde editar. Nunca solicite nem revele chaves de API ou segredos."
          }]
        },
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        generationConfig: {
          temperature: 0.75,
          maxOutputTokens: tool === "landing" ? 7000 : 2200
        }
      })
    });

    const result = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      const upstreamMessage = result?.error?.message || "O Google Gemini recusou a solicitação.";
      const safeMessage = upstream.status === 400
        ? `O Gemini rejeitou o pedido. Confira o modelo configurado e o formato da solicitação. Detalhe: ${upstreamMessage}`
        : upstream.status === 401 || upstream.status === 403
          ? "O Gemini não aceitou a chave. Confira se GEMINI_API_KEY foi copiada corretamente, se a API está habilitada e se a chave tem permissão."
          : upstream.status === 429
            ? "O limite de uso do Gemini foi atingido. Aguarde e tente novamente ou confira a cota no Google AI Studio."
            : `Erro do Gemini (${upstream.status}): ${upstreamMessage}`;
      return Response.json({ error: safeMessage }, { status: upstream.status === 429 ? 429 : 502, headers });
    }

    const text = (result?.candidates?.[0]?.content?.parts || [])
      .map(part => typeof part.text === "string" ? part.text : "")
      .join("\n")
      .trim();

    if (!text) {
      const reason = result?.candidates?.[0]?.finishReason;
      return Response.json({ error: `O Gemini não retornou texto${reason ? ` (motivo: ${reason})` : ""}. Tente reformular o pedido.` }, { status: 502, headers });
    }

    return Response.json({ text, model }, { status: 200, headers });
  } catch (error) {
    return Response.json({ error: "Erro interno ao processar o pedido. Tente novamente. " + (error?.message || "") }, { status: 500, headers });
  }
}

export async function onRequestGet() {
  return Response.json({
    ok: true,
    service: "EA Creator Hub API",
    message: "A função está publicada. Para gerar conteúdo, envie POST para /api/generate."
  }, { headers: { "Cache-Control": "no-store" } });
}
