# EA Creator Hub — guia de publicação

Este projeto é uma PWA (aplicativo web instalável) com interface inspirada em apps de mensagens e ferramentas de criação de conteúdo. A geração de texto usa Gemini por meio de uma Cloudflare Pages Function. A chave não deve ser colocada no HTML, no JavaScript do navegador nem no GitHub.

## O que já está incluído

- Interface responsiva para celular e computador.
- Tela inicial animada com marca EA.
- Atalhos para copy, roteiros, anúncios, hashtags, ganchos, landing pages, ideias e identidade visual.
- Conversa visual com mensagens e resultados gerados.
- Copiar e salvar resultados em “Meus materiais”.
- Kit de identidade visual salvo localmente.
- Planejador de conteúdo salvo localmente.
- Manifesto PWA, ícone e service worker.
- Endpoint `GET /api/generate` para verificar se a função está publicada.
- Endpoint `POST /api/generate` para chamar o Gemini com a chave guardada no servidor.

## 1. Enviar para o GitHub

1. Baixe e extraia o ZIP.
2. Crie um repositório no GitHub.
3. Envie **o conteúdo da pasta**, não apenas o ZIP. Na raiz do repositório devem aparecer `index.html`, `app.js`, `styles.css`, `manifest.webmanifest`, `sw.js` e a pasta `functions`.
4. Confirme que existe `functions/api/generate.js`. Essa pasta é necessária para a função de servidor.

## 2. Criar o projeto Cloudflare Pages

1. Entre no painel Cloudflare.
2. Acesse **Workers & Pages** e crie um projeto Pages conectado ao repositório GitHub.
3. Para este projeto sem etapa de build, use:
   - Framework preset: **None**
   - Build command: deixe vazio
   - Build output directory: `/` ou `.` (use a opção aceita pelo painel para servir a raiz do repositório)
4. Salve e aguarde o deploy.
5. Abra o domínio `*.pages.dev` criado pela Cloudflare.

Se o painel exigir um diretório de saída específico, escolha a raiz do projeto ou consulte as opções atuais de Pages para um site estático sem build. Não mova nem remova a pasta `functions`.

## 3. Configurar a chave Gemini como segredo

1. Abra o projeto Pages no painel Cloudflare.
2. Entre em **Settings → Variables and Secrets** (o nome exato pode variar conforme a interface).
3. Adicione uma variável do tipo **Secret**:
   - Nome: `GEMINI_API_KEY`
   - Valor: sua chave privada criada no Google AI Studio
4. Salve e faça um novo deploy, se a Cloudflare solicitar.

**Nunca** cole a chave no `app.js`, `index.html`, em uma variável pública `VITE_*`, em um repositório GitHub ou em mensagens públicas. Este projeto só lê `env.GEMINI_API_KEY` dentro da função no servidor.

## 4. Modelo Gemini

O projeto usa por padrão `gemini-3.8-flash`, conforme a documentação consultada ao montar este projeto. A disponibilidade de modelos pode variar por conta e mudar com o tempo. Se esse modelo não estiver disponível para sua chave, adicione outra variável no projeto Pages:

- Nome: `GEMINI_MODEL`
- Valor: o nome exato de um modelo que esteja disponível para sua conta no Google AI Studio (sem o prefixo `models/`)

Exemplo de formato: `gemini-2.5-flash` — use somente se ele aparecer como disponível para sua conta. Salve e faça novo deploy.

## 5. Testar

1. Abra `https://SEU-DOMINIO.pages.dev/api/generate` no navegador. A função deve responder com um JSON dizendo que a API está publicada.
2. No site, toque em ⚙ Configurações → **Testar conexão com Gemini**.
3. Se falhar, leia a mensagem. Ela pode indicar chave ausente, chave inválida/permissão, modelo indisponível ou limite de uso.
4. Depois teste “Criar copy” com um pedido simples, por exemplo: `Crie uma legenda curta para divulgar uma garrafa térmica. Benefício: mantém a bebida quente ou fria.`

## 6. Instalar no celular e computador

- **Android / Chrome:** abra o endereço HTTPS do site, use a opção “Instalar app” ou “Adicionar à tela inicial”. O botão de instalação aparece quando o navegador oferece o evento de instalação.
- **Computador:** em navegadores compatíveis, use o ícone de instalação na barra de endereços ou o menu do navegador.
- A disponibilidade e o texto da opção de instalação variam conforme o navegador e a plataforma.

## Importante sobre dados e custos

- A chave fica no servidor, mas o endpoint ainda deve ser protegido contra uso abusivo antes de compartilhar publicamente com muitas pessoas. Para um lançamento público, adicione limites por IP/usuário, autenticação e monitoramento de uso.
- As ferramentas de IA consomem a cota da API Gemini vinculada à sua chave. Os limites e preços dependem do modelo e da conta.
- “Meus materiais”, identidade visual e planejador usam armazenamento local do navegador. Esses dados não sincronizam automaticamente entre dispositivos e podem ser apagados ao limpar os dados do navegador.
- O service worker guarda os arquivos da interface para melhorar a abertura. A geração com Gemini requer conexão com a internet.
- A tela inicial é uma animação de abertura, não um sistema de autenticação. O app só informa que o Gemini está conectado após uma resposta bem-sucedida.
