const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const toolMeta = {
  copy:{label:"Criar copy",prompt:"Crie uma copy clara e envolvente para o seguinte objetivo. Inclua uma abertura forte, benefícios reais e uma chamada para ação. Não invente características do produto.",placeholder:"Conte sobre o produto, público e objetivo…",icon:"✎"},
  roteiro:{label:"Roteiro de vídeo",prompt:"Crie um roteiro de vídeo curto em português brasileiro, com gancho inicial, cenas ou falas, desenvolvimento e CTA. Seja natural e adapte a duração ao pedido.",placeholder:"Qual é o tema, público e duração do vídeo?",icon:"▷"},
  anuncio:{label:"Criar anúncio",prompt:"Crie três versões de anúncio para o produto ou serviço descrito: direta, emocional e curta. Destaque benefícios informados, evite promessas não comprovadas e finalize com CTA.",placeholder:"Descreva o produto, preço, público e oferta…",icon:"↗"},
  hashtags:{label:"Organizador de hashtags",prompt:"Sugira hashtags relevantes para o tema descrito, organizadas em grupos: específicas, de nicho e mais amplas. Evite garantir viralização e explique brevemente como selecionar as mais relevantes.",placeholder:"Qual é o assunto, nicho e rede social?",icon:"#"},
  ganchos:{label:"Ganchos para conteúdo",prompt:"Gere 15 ganchos curtos e variados para abrir um vídeo ou publicação sobre o tema. Misture curiosidade, problema, benefício, comparação e pergunta sem inventar dados.",placeholder:"Qual tema você quer transformar em conteúdo?",icon:"⚡"},
  landing:{label:"Criador de landing page",prompt:"Crie um briefing completo e uma estrutura de landing page responsiva em português brasileiro. Inclua hero, benefícios, como funciona, prova social apenas como espaço para depoimentos reais, FAQ e CTA. Gere código HTML/CSS/JS autocontido e acessível. Use apenas fatos fornecidos; marque como [EDITAR] dados ausentes. Separe a explicação do código.",placeholder:"Nome do negócio, objetivo, cores, oferta e links…",icon:"▱"},
  ideias:{label:"Ideias de conteúdo",prompt:"Gere 20 ideias de conteúdo específicas para o nicho informado. Para cada uma, indique formato, ângulo e objetivo. Evite ideias genéricas e organize do mais simples ao mais elaborado.",placeholder:"Qual é o seu nicho e para quem cria?",icon:"✧"},
  identidade:{label:"Kit de identidade visual",prompt:"Monte um kit inicial de identidade visual para a marca descrita: personalidade, paleta com códigos HEX, sugestões de fontes seguras, tom de voz, palavras a usar e evitar e direções visuais. Não afirme que criou arquivos gráficos.",placeholder:"Nome da marca, público, segmento e estilo desejado…",icon:"◈"},
  test:{label:"Teste de conexão",prompt:"Responda exatamente: A conexão do EA Creator Hub com o Gemini está funcionando.",placeholder:"",icon:"✓"}
};
let activeTool = "copy";
let isBusy = false;
let deferredInstallPrompt = null;
let toastTimer = null;

const readStore = (key, fallback=[]) => { try { const v=JSON.parse(localStorage.getItem(key)); return v ?? fallback; } catch { return fallback; } };
const writeStore = (key, value) => localStorage.setItem(key, JSON.stringify(value));
let savedMaterials = readStore("ea-hub-materials", []);
let plannerItems = readStore("ea-hub-planner", []);
let brandSettings = readStore("ea-hub-brand", {name:"",slogan:"",color:"#0d9f78",font:"",tone:"Amigável e simples"});

function toast(message) {
  const el=$("#toast"); el.textContent=message; el.classList.add("show");
  clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove("show"),2800);
}
function escapeHtml(s="") { return String(s).replace(/[&<>"']/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function nowTime(){return new Intl.DateTimeFormat("pt-BR",{hour:"2-digit",minute:"2-digit"}).format(new Date());}
function setActiveTool(tool){
  activeTool=toolMeta[tool]?tool:"copy";
  $$(".tool-chip").forEach(b=>b.classList.toggle("selected",b.dataset.tool===activeTool));
  $("#active-tool-label").textContent="Ferramenta: "+toolMeta[activeTool].label;
  $("#prompt-input").placeholder=toolMeta[activeTool].placeholder;
  $("#prompt-input").focus({preventScroll:true});
}
function switchView(view){
  $$(".view").forEach(el=>el.classList.toggle("active",el.id===view+"-view"));
  $$("[data-view]").forEach(el=>el.classList.toggle("active",el.dataset.view===view));
  if(view==="materials") renderMaterials();
  if(view==="planner") renderPlanner();
  if(view==="brand") loadBrandForm();
  window.scrollTo({top:0,behavior:"smooth"});
}
function appendMessage(text, who="assistant", opts={}){
  const row=document.createElement("div"); row.className="message-row "+(who==="user"?"user-row":"assistant-row");
  if(who!=="user"){const av=document.createElement("div");av.className="mini-avatar";av.textContent="EA";row.append(av);}
  const bubble=document.createElement("div");bubble.className="bubble "+(who==="user"?"user-bubble":"assistant-bubble");
  if(who!=="user"){const name=document.createElement("div");name.className="bubble-name";name.textContent="EA Creator Hub";bubble.append(name);}
  const p=document.createElement("p");p.textContent=text;bubble.append(p);
  if(opts.code){const pre=document.createElement("code");pre.className="code-output";pre.textContent=opts.code;bubble.append(pre);}
  const time=document.createElement("span");time.className="message-time";time.textContent=nowTime();bubble.append(time);
  if(who!=="user" && opts.saveText){
    const actions=document.createElement("div");actions.className="bubble-actions";
    const copy=document.createElement("button");copy.className="tiny-action";copy.textContent="Copiar resultado";copy.addEventListener("click",()=>copyText(opts.saveText));
    const save=document.createElement("button");save.className="tiny-action";save.textContent="Salvar material";save.addEventListener("click",()=>saveMaterial(toolMeta[activeTool]?.label||"Conteúdo criado",opts.saveText,activeTool));
    actions.append(copy,save);bubble.append(actions);
  }
  row.append(bubble);$("#conversation").append(row);$("#conversation").scrollTop=$("#conversation").scrollHeight;return row;
}
function showTyping(){
  const row=document.createElement("div");row.className="message-row assistant-row";row.id="typing-indicator";
  row.innerHTML='<div class="mini-avatar">EA</div><div class="bubble assistant-bubble"><div class="bubble-name">EA Creator Hub</div><div class="typing"><span></span><span></span><span></span></div><p>Preparando sua resposta…</p></div>';
  $("#conversation").append(row);$("#conversation").scrollTop=$("#conversation").scrollHeight;
}
async function copyText(text){
  try{await navigator.clipboard.writeText(text);toast("Copiado para a área de transferência!");}
  catch{const ta=document.createElement("textarea");ta.value=text;document.body.append(ta);ta.select();const ok=document.execCommand("copy");ta.remove();toast(ok?"Copiado!":"Não foi possível copiar automaticamente.");}
}
async function generate(promptOverride=null){
  if(isBusy)return;
  const input=$("#prompt-input");const userText=(promptOverride??input.value).trim();
  if(!userText){toast("Escreva o que você precisa primeiro.");input.focus();return;}
  const meta=toolMeta[activeTool];isBusy=true;$("#send-button").disabled=true;$("#send-button span").textContent="Gerando…";
  appendMessage(userText,"user");input.value="";showTyping();
  const toolPrompt=`Ferramenta escolhida: ${meta.label}.\nInstruções da ferramenta: ${meta.prompt}\nPedido do usuário: ${userText}\n\nResponda em português brasileiro. Seja prático, organizado e entregue um resultado que possa ser usado.`;
  try{
    const response=await fetch("/api/generate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt:toolPrompt,tool:activeTool})});
    const data=await response.json().catch(()=>({}));
    if(!response.ok) throw new Error(data.error||`Erro HTTP ${response.status}. Verifique a configuração da Cloudflare.`);
    const result=String(data.text||"").trim();
    if(!result)throw new Error("O Gemini respondeu sem texto. Tente novamente.");
    $("#typing-indicator")?.remove();
    const codeMatch=activeTool==="landing"?result.match(/```(?:html)?\s*([\s\S]*?)```/i):null;
    appendMessage(result,"assistant",{saveText:result,code:codeMatch?.[1]});
    $("#api-status-title").textContent="Gemini conectado";$("#api-status-text").textContent="A última solicitação respondeu corretamente.";
    $("#api-dot").style.background="#0d9f78";
  }catch(err){
    $("#typing-indicator")?.remove();
    appendMessage("Não consegui gerar agora. "+friendlyError(err.message)+"\n\nSe você acabou de publicar, confirme se a pasta functions/api/generate.js foi enviada ao GitHub e se o segredo GEMINI_API_KEY foi configurado nas variáveis do projeto Cloudflare Pages.","assistant");
    $("#api-status-title").textContent="Não foi possível conectar";$("#api-status-text").textContent=err.message;$("#api-dot").style.background="#d97706";
  }finally{
    isBusy=false;$("#send-button").disabled=false;$("#send-button span").textContent="Gerar";input.focus({preventScroll:true});
  }
}
function friendlyError(msg){
  if(/Failed to fetch|NetworkError/i.test(msg))return "Não consegui alcançar a função do servidor. Confira se o site está publicado e se a URL está correta.";
  return msg;
}
function saveMaterial(title,content,type){
  savedMaterials.unshift({id:crypto.randomUUID?.()||String(Date.now()),title,content,type,createdAt:new Date().toISOString()});
  writeStore("ea-hub-materials",savedMaterials);updateCounts();toast("Material salvo neste dispositivo.");renderMaterials();
}
function deleteMaterial(id){savedMaterials=savedMaterials.filter(m=>m.id!==id);writeStore("ea-hub-materials",savedMaterials);updateCounts();renderMaterials();toast("Material removido.");}
function renderMaterials(){
  const q=($("#materials-search").value||"").toLowerCase();
  const list=$("#materials-list");const rows=savedMaterials.filter(m=>(m.title+" "+m.content).toLowerCase().includes(q));
  if(!rows.length){list.innerHTML='<div class="empty-state"><strong>Nenhum material por aqui ainda.</strong><br>Gere uma copy, roteiro ou ideia e toque em “Salvar material”.</div>';return;}
  list.innerHTML=rows.map(m=>`<article class="material-card"><div class="material-card-head"><div class="material-type">${escapeHtml((m.title||"M").slice(0,1).toUpperCase())}</div><div class="material-info"><strong>${escapeHtml(m.title)}</strong><small>${escapeHtml(new Date(m.createdAt).toLocaleString("pt-BR"))} · ${escapeHtml(m.type||"material")}</small></div></div><div class="material-content">${escapeHtml(m.content.length>420?m.content.slice(0,420)+"…":m.content)}</div><div class="card-actions"><button data-copy="${escapeHtml(m.id)}">Copiar</button><button data-delete="${escapeHtml(m.id)}">Excluir</button></div></article>`).join("");
  $$("[data-copy]",list).forEach(b=>b.onclick=()=>{const m=savedMaterials.find(x=>x.id===b.dataset.copy);if(m)copyText(m.content);});
  $$("[data-delete]",list).forEach(b=>b.onclick=()=>deleteMaterial(b.dataset.delete));
}
function updateCounts(){
  const n=savedMaterials.length;$("#saved-count-side").textContent=n;$("#saved-count-mobile").textContent=n;$("#nav-count").textContent=n;$("#nav-count").classList.toggle("hidden",!n);
}
function loadBrandForm(){
  $("#brand-name").value=brandSettings.name||"";$("#brand-slogan").value=brandSettings.slogan||"";$("#brand-color").value=brandSettings.color||"#0d9f78";$("#brand-font").value=brandSettings.font||"";$("#brand-tone").value=brandSettings.tone||"Amigável e simples";renderBrandPreview();
}
function renderBrandPreview(){
  const color=$("#brand-color").value||"#0d9f78";$(".preview-swatch").style.background=color;
  $(".brand-preview strong").textContent=$("#brand-name").value||"Sua marca";
  $(".brand-preview p").textContent=$("#brand-slogan").value||"Prévia da identidade";
}
function saveBrand(e){
  e.preventDefault();brandSettings={name:$("#brand-name").value.trim(),slogan:$("#brand-slogan").value.trim(),color:$("#brand-color").value,font:$("#brand-font").value.trim(),tone:$("#brand-tone").value};
  writeStore("ea-hub-brand",brandSettings);renderBrandPreview();toast("Identidade visual salva.");
}
function renderPlanner(){
  const list=$("#planner-list");
  if(!plannerItems.length){list.innerHTML='<div class="empty-state"><strong>Seu planejamento começa aqui.</strong><br>Adicione uma ideia acima para organizar suas próximas publicações.</div>';return;}
  list.innerHTML=plannerItems.slice().sort((a,b)=>(a.date||"9999").localeCompare(b.date||"9999")).map(item=>`<article class="planner-card"><div class="planner-card-head"><div class="material-type">▦</div><div class="material-info"><strong>${escapeHtml(item.title)}</strong><div class="planner-meta"><span>${escapeHtml(item.channel)}</span><span>${item.date?escapeHtml(new Date(item.date+"T12:00:00").toLocaleDateString("pt-BR")):"Sem data"}</span></div></div><span class="status-pill">${escapeHtml(item.status)}</span></div><div class="card-actions" style="margin-top:12px"><button data-next="${escapeHtml(item.id)}">Avançar status</button><button data-plan-delete="${escapeHtml(item.id)}">Excluir</button></div></article>`).join("");
  $$("[data-next]",list).forEach(b=>b.onclick=()=>{const statuses=["Ideia","Em produção","Pronto para publicar","Publicado"];const item=plannerItems.find(x=>x.id===b.dataset.next);if(item){item.status=statuses[(statuses.indexOf(item.status)+1)%statuses.length];writeStore("ea-hub-planner",plannerItems);renderPlanner();}});
  $$("[data-plan-delete]",list).forEach(b=>b.onclick=()=>{plannerItems=plannerItems.filter(x=>x.id!==b.dataset.planDelete);writeStore("ea-hub-planner",plannerItems);renderPlanner();});
}
async function testApi(){
  $("#api-status-title").textContent="Testando conexão…";$("#api-status-text").textContent="Enviando uma solicitação de teste.";
  try{
    const res=await fetch("/api/generate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt:"Responda exatamente: Teste do EA Creator Hub concluído.",tool:"test"})});
    const data=await res.json().catch(()=>({}));
    if(!res.ok)throw new Error(data.error||`Erro HTTP ${res.status}`);
    $("#api-status-title").textContent="Gemini conectado";$("#api-status-text").textContent="Teste concluído: "+(data.text||"resposta recebida");
    $("#api-dot").style.background="#0d9f78";toast("Conexão com Gemini testada com sucesso.");
  }catch(e){$("#api-status-title").textContent="Conexão não confirmada";$("#api-status-text").textContent=e.message;$("#api-dot").style.background="#d97706";toast("Não foi possível confirmar a conexão.");}
}
function init(){
  $$(".tool-chip").forEach(b=>b.addEventListener("click",()=>setActiveTool(b.dataset.tool)));
  $$("[data-view]").forEach(b=>b.addEventListener("click",()=>switchView(b.dataset.view)));
  $("#prompt-form").addEventListener("submit",e=>{e.preventDefault();generate();});
  $("#brand-form").addEventListener("submit",saveBrand);
  ["brand-name","brand-slogan","brand-color"].forEach(id=>$("#"+id).addEventListener("input",renderBrandPreview));
  $("#planner-form").addEventListener("submit",e=>{
    e.preventDefault();plannerItems.push({id:crypto.randomUUID?.()||String(Date.now()),title:$("#plan-title").value.trim(),channel:$("#plan-channel").value,date:$("#plan-date").value,status:$("#plan-status").value});
    writeStore("ea-hub-planner",plannerItems);$("#plan-title").value="";toast("Ideia adicionada ao planejamento.");renderPlanner();
  });
  $("#materials-search").addEventListener("input",renderMaterials);
  $("#settings-button").addEventListener("click",()=>$("#settings-dialog").showModal());
  $("#test-api").addEventListener("click",testApi);
  $("#clear-data").addEventListener("click",()=>{
    if(confirm("Apagar materiais, planejamento e identidade visual salvos neste dispositivo?")){
      ["ea-hub-materials","ea-hub-planner","ea-hub-brand"].forEach(k=>localStorage.removeItem(k));
      savedMaterials=[];plannerItems=[];brandSettings={name:"",slogan:"",color:"#0d9f78",font:"",tone:"Amigável e simples"};
      updateCounts();renderMaterials();renderPlanner();loadBrandForm();toast("Dados locais apagados.");
    }
  });
  window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredInstallPrompt=e;$("#install-button").classList.remove("hidden");});
  $("#install-button").addEventListener("click",async()=>{
    if(!deferredInstallPrompt){toast("Use o menu do navegador e escolha “Instalar app” ou “Adicionar à tela inicial”.");return;}
    deferredInstallPrompt.prompt();await deferredInstallPrompt.userChoice;deferredInstallPrompt=null;$("#install-button").classList.add("hidden");
  });
  if("serviceWorker" in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("/sw.js").catch(()=>{});
  updateCounts();loadBrandForm();renderMaterials();renderPlanner();
  setTimeout(()=>{$("#splash-status").textContent="Quase pronto…";},400);
  setTimeout(()=>{$("#splash").classList.add("fade");$("#app").classList.remove("hidden");setTimeout(()=>$("#splash").remove(),400);},1050);
}
document.addEventListener("DOMContentLoaded",init);
